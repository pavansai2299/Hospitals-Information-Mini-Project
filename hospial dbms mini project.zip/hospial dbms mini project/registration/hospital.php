<html>
<center><head>Nearby Hospitals</head></center><br/>
<body style="background-color:yellow";>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dbms";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
if($_SERVER['REQUEST_METHOD']==='POST'){
$value = $_POST['place'];

$sql = "SELECT Hospital_name,distance from place where place_name='".$value."'; ";
$result = $conn->query($sql);

//echo $sql;
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
		echo "Hospital Name: " . $row["Hospital_name"]. "<br>","Distance : " . $row["distance"]. "mts", "<br><br><br><br><br>";
		
    }
} else {
    echo "0 results";
}
}
$conn->close();
?>

<form action = "/registration/doctor.php" method="post" />
  <p>Enter your hospital name: <input type="text" name="hname" /></p><br>
  <input type="submit" value="Details" />
</form>

<br><br><br>
<form action = "/registration/place.php" method="post" />
  <!--<p>Enter the specilization: <input type="text" name="sname" /></p><br>-->
  <input type="submit" value="Go To Homepage" />
</form>


</body>
</html>