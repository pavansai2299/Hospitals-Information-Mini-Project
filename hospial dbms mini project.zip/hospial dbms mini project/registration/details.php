<?php include('server.php') ?>
<html>
<center><head><u>Doctor Details</u></head></center><br/>
<body style="background-color:yellow";>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dbms";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
if($_SERVER['REQUEST_METHOD']==='POST'){
$value = $_POST['dname'];

$sql = "SELECT doctors.Timings,doctors.Fee,doctors.Mobile_number,doctors.Availability from hospitals inner join doctors on hospitals.Did = doctors.did where hospitals.name='".$value."'; ";
$result = $conn->query($sql);

//echo $sql;
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
		//echo "$value","<br>";
		echo "Timings: " . $row["Timings"]. "<br>","Fee : " . $row["Fee"]. "<br>","Mobile number : " .$row["Mobile_number"]. "<br>","Availability : " .$row["Availability"]. "<br><br><br><br><br>";
		
    }
} else {
    echo "0 results";
}
}
$conn->close();
?>
<br><br>
<!---<button onclick="myFunction()">Make Appointment</button>

<script>
function myFunction() {
    alert("Your appointment was successful!");
}
</script>-->

<form action = "/registration/data.php" method="post" />
  <input type="hidden" name="username" value="<?php echo $_SESSION['username']; ?>"/>
  <input type="hidden" name="email" value="<?php echo $_SESSION['email']; ?>"/>
  <input type="submit" value="Make Appointment" />
</form>


<br><br><br>
<form action = "/registration/place.php" method="post" />
  <!--<p>Enter the specilization: <input type="text" name="sname" /></p><br>-->
  <input type="submit" value="Go To HomePage" />
</form>

</body>
</html>