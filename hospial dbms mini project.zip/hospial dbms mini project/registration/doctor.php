<html>
<center><head><u>Hospital Details</u></head></center><br/>
<body style="background-color:yellow";>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dbms";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
if($_SERVER['REQUEST_METHOD']==='POST'){
$value = $_POST['hname'];

$sql = "SELECT hospitals.name,hospitals.Address,specilization.specilization from place inner join hospitals on place.Hid = hospitals.Hid inner join specilization on hospitals.spid = specilization.spid where place.Hospital_name='".$value."'; ";
$result = $conn->query($sql);

//echo $sql;
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
		//echo "$value","<br>";
		echo "Doctor Name: " . $row["name"]. "<br>","Address : " . $row["Address"]. "<br>","specilization : " . $row["specilization"]."<br><br><br><br><br>";
		
    }
} else {
    echo "0 results";
}
}
$conn->close();
?>
<form action = "/registration/details.php" method="post" />
  <p>Enter your Doctor name: <input type="text" name="dname" /></p><br>
  <input type="submit" value="Details" />
</form>

<br><br><br>

<form action = "/registration/place.php" method="post" />
  <!--<p>Enter the specilization: <input type="text" name="sname" /></p><br>-->
  <input type="submit" value="Go To Homepage" />
</form>

</body>
</html>