<html>
<center><head>Detailed Information</head></center><br/>
<body style="background-color:yellow";>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dbms";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
if($_SERVER['REQUEST_METHOD']==='POST'){
$valu = $_POST['fname'];
$value2 = $_POST['sname'];
$sql = "SELECT place.place_name,place.Hospital_name,hospitals.name,hospitals.Address,place.distance,doctors.Fee from place inner join hospitals on place.Hid = hospitals.Hid inner join specilization on hospitals.spid = specilization.spid inner join doctors on hospitals.Did = doctors.did where doctors.Fee <=$valu and specilization.specilization ='".$value2."'; ";
$result = $conn->query($sql);

//echo $sql;
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
		echo "place: " .$row["place_name"]. "<br>", "Hospital Name: " . $row["Hospital_name"]. "<br>", "Doctor Name: " . $row["name"]. "<br>", "Address :" .$row["Address"]. "<br>", "Distance : " . $row["distance"]. "mts", "<br>", "Fee : " . $row["Fee"]. "<br><br><br><br><br>";
		
    }
} else {
    echo "0 results";
}
}
$conn->close();
?>
<form action = "/registration/details.php" method="post" />
  <p>Enter your Doctor name: <input type="text" name="dname" /></p><br>
  <input type="submit" value="Details" />
</form>

<br><br><br>
<form action = "/registration/place.php" method="post" />
  <!--<p>Enter the specilization: <input type="text" name="sname" /></p><br>-->
  <input type="submit" value="Go To HomePage" />
</form>

</body>
</html>