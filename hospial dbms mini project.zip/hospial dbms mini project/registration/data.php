<?php include('server.php') ?>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hospital";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
if($_SERVER['REQUEST_METHOD']==='POST'){
	$value=mysqli_real_escape_string($db, $_POST['username']);
	//$value1=mysqli_real_escape_string($db, $_POST['email']);
//echo $value;
$sql = "INSERT INTO details ( Name)
VALUES ('".$value."')";
if ($conn->query($sql) === TRUE) {
    echo "Your appointment is successful!";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
}
$conn->close();
?>